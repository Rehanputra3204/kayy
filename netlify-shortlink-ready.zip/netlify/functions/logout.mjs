import { json, clearCookie } from './_shared.mjs';
export default async () => json({ok:true},200,{'Set-Cookie':clearCookie});
