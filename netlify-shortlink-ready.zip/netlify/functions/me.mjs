import { json, isAuthed } from './_shared.mjs';
export default async (request, context) => json({loggedIn:await isAuthed(request,context.env)});
