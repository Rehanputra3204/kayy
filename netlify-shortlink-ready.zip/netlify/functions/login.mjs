import { json, makeSession, cookie } from './_shared.mjs';
export default async (request, context) => {
  if(request.method!=='POST')return json({error:'Metode tidak didukung'},405);
  const {username,password}=await request.json().catch(()=>({}));
  if(!context.env.ADMIN_PASSWORD)return json({error:'ADMIN_PASSWORD belum diatur di Netlify Environment variables.'},500);
  if(!context.env.SESSION_SECRET || context.env.SESSION_SECRET.length<32)return json({error:'SESSION_SECRET belum diatur (minimal 32 karakter) di Netlify Environment variables.'},500);
  if(username!=='admin' || password!==context.env.ADMIN_PASSWORD)return json({error:'Username atau password salah.'},401);
  const token=await makeSession(context.env.SESSION_SECRET);
  return json({ok:true},200,{'Set-Cookie':cookie(token)});
};
