import { getStore } from '@netlify/blobs';

export const json = (data, status=200, extra={}) => new Response(JSON.stringify(data), {
  status, headers: { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', ...extra }
});
export const store = () => getStore({ name:'shortlinks', consistency:'strong' });
const enc = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
async function signature(payload, secret) {
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  return enc(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(payload)));
}
export async function makeSession(secret) {
  const payload=enc(new TextEncoder().encode(JSON.stringify({exp:Date.now()+86400000,nonce:crypto.randomUUID()})));
  return payload+'.'+await signature(payload,secret);
}
export async function isAuthed(request, env) {
  if(!env.SESSION_SECRET || env.SESSION_SECRET.length<32) return false;
  const m=(request.headers.get('cookie')||'').match(/(?:^|;\s*)sl_session=([^;]+)/);
  if(!m)return false;
  const parts=m[1].split('.');
  if(parts.length!==2 || await signature(parts[0],env.SESSION_SECRET)!==parts[1])return false;
  try { return JSON.parse(atob(parts[0].replace(/-/g,'+').replace(/_/g,'/'))).exp>Date.now(); } catch { return false; }
}
export const cookie = value => `sl_session=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=86400`;
export const clearCookie = 'sl_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0';
export const randomSlug = () => {
  const chars='abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const b=new Uint8Array(7);crypto.getRandomValues(b);
  return [...b].map(x=>chars[x%chars.length]).join('');
};
