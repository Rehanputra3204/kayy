import { json, isAuthed, store, randomSlug } from './_shared.mjs';
export default async (request, context) => {
  if(!await isAuthed(request,context.env))return json({error:'Belum login'},401);
  const db=store();
  if(request.method==='GET'){
    const {blobs}=await db.list();
    const links=[];
    for(const b of blobs){const item=await db.get(b.key,{type:'json'});if(item)links.push(item);}
    links.sort((a,b)=>b.createdAt-a.createdAt);
    return json({links});
  }
  if(request.method==='POST'){
    const body=await request.json().catch(()=>({}));
    let u;try{u=new URL(body.url)}catch{return json({error:'URL tujuan tidak valid.'},400)}
    if(!['http:','https:'].includes(u.protocol))return json({error:'URL harus menggunakan http atau https.'},400);
    const slug=String(body.slug||randomSlug()).trim().replace(/[^a-zA-Z0-9_-]/g,'').slice(0,60);
    if(!slug)return json({error:'Custom slug tidak valid.'},400);
    if(await db.get(slug))return json({error:'Slug sudah digunakan. Pilih slug lain.'},409);
    const item={slug,url:u.href,clicks:0,createdAt:Date.now()};
    await db.setJSON(slug,item);
    return json({ok:true,shortUrl:new URL('/s/'+slug,request.url).href,link:item},201);
  }
  return json({error:'Metode tidak didukung'},405);
};
