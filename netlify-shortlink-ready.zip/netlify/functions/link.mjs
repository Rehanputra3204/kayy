import { json, isAuthed, store } from './_shared.mjs';
export default async (request, context) => {
  if(request.method!=='DELETE')return json({error:'Metode tidak didukung'},405);
  if(!await isAuthed(request,context.env))return json({error:'Belum login'},401);
  const slug=new URL(request.url).searchParams.get('slug')||'';
  if(!slug)return json({error:'Slug tidak ada'},400);
  await store().delete(slug);
  return json({ok:true});
};
