import { store } from './_shared.mjs';
export default async request => {
  const slug=new URL(request.url).searchParams.get('slug')||'';
  if(!/^[a-zA-Z0-9_-]{1,60}$/.test(slug))return new Response('Shortlink tidak ditemukan.',{status:404});
  const db=store();
  const item=await db.get(slug,{type:'json'});
  if(!item || !item.url)return new Response('Shortlink tidak ditemukan.',{status:404,headers:{'Content-Type':'text/plain; charset=utf-8'}});
  item.clicks=(item.clicks||0)+1;
  await db.setJSON(slug,item);
  return Response.redirect(item.url,302);
};
