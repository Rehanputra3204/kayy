SHORTLINK ADMIN — NETLIFY

Fitur:
- Login admin (password dari environment variable)
- Buat shortlink otomatis atau custom slug
- Redirect /s/slug
- Statistik klik
- Penyimpanan persisten memakai Netlify Blobs

PENTING SOAL DEPLOY ZIP:
Netlify Drop untuk upload folder/ZIP statis tidak menjalankan Netlify Functions dengan benar untuk aplikasi ini. Aplikasi ini membutuhkan Functions dan Netlify Blobs. Cara termudah dari HP Android:
1) Buat akun / login di https://app.netlify.com/
2) Buat repository GitHub dan upload isi ZIP ini ke root repository (bisa dari browser GitHub di HP).
3) Di Netlify pilih Add new site > Import an existing project > GitHub dan pilih repository.
4) Build command: biarkan kosong. Publish directory: public.
5) Deploy site.
6) Site configuration / Environment variables (atau Site settings > Environment variables):
   ADMIN_PASSWORD = password admin pilihanmu
   SESSION_SECRET = secret acak panjang minimal 32 karakter
7) Trigger deploy ulang setelah menambah environment variables.
8) Setelah deploy, buka site URL Netlify.

Data shortlink disimpan dalam Netlify Blobs. Pada beberapa akun/konfigurasi, Blobs perlu tersedia/diaktifkan oleh Netlify; jika muncul error storage, periksa Netlify Functions/Blobs di dashboard.

Login:
Username: admin
Password: nilai ADMIN_PASSWORD yang kamu set.

Keamanan:
- Jangan bagikan ADMIN_PASSWORD atau SESSION_SECRET.
- Pakai password admin yang kuat.
- Untuk aplikasi produksi, tambahkan pembatasan percobaan login/rate limiting jika dibuka publik.
